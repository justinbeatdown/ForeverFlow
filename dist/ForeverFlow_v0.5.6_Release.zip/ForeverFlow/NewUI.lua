-- ForeverFlow / Rebuilt UI: independent native WoW interface, native resize pass.
-- This file deliberately DOES NOT import UI.lua, PremiumUI.lua, PremiumPages.lua,
-- Theme.lua, or any previous screen builders. Game logic remains intact.
local _, FF = ...
local M=FF.media..'NewUI\\'
local WHITE={.96,.91,.81};local DIM={.71,.67,.60};local GOLD={1,.78,.35}
local GREEN={.45,.89,.48};local RED={1,.43,.35};local AMBER={1,.66,.26}
local unpack=unpack or table.unpack
local W,H=1160,710
local function str(x) return tostring(x or '') end
local function cut(t,n)
 t=str(t);if #t>n then return t:sub(1,n-3)..'...' end;return t
end
local function txt(parent,t,x,y,w,h,size,color,align,wrap)
 local f=parent:CreateFontString(nil,'OVERLAY')
 f:SetFont(STANDARD_TEXT_FONT,size or 13,'')
 f:SetPoint('TOPLEFT',parent,'TOPLEFT',x,-y);f:SetSize(w,h or 20)
 f:SetJustifyH(align or 'LEFT');f:SetJustifyV('MIDDLE')
 f:SetWordWrap(wrap==true);f:SetText(t or '');f:SetTextColor(unpack(color or WHITE))
 return f
end
local function img(parent,texture,x,y,w,h)
 local t=parent:CreateTexture(nil,'ARTWORK')
 t:SetTexture(texture);t:SetPoint('TOPLEFT',parent,'TOPLEFT',x,-y);t:SetSize(w,h)
 return t
end
local function skin(parent,style,r)
 -- Genuine independently rendered nine-slice artwork, never stretched captures.
 r=r or 12;local tex={}
 local tiles={{0,0,r,r},{r,0,1,r},{-r,0,r,r},
              {0,r,r,1},{r,r,1,1},{-r,r,r,1},
              {0,-r,r,r},{r,-r,1,r},{-r,-r,r,r}}
 for i=1,9 do
  local y=math.floor((i-1)/3);local x=(i-1)%3
  local t=parent:CreateTexture(nil,'BACKGROUND')
  t:SetTexture(M..style..'_'..y..x..'.tga')
  tex[i]=t
 end
 local function size()
  local w,h=parent:GetWidth(),parent:GetHeight()
  if not w or not h or w<=2*r or h<=2*r then return end
  local coords={{0,0,r,r},{r,0,w-2*r,r},{w-r,0,r,r},
   {0,r,r,h-2*r},{r,r,w-2*r,h-2*r},{w-r,r,r,h-2*r},
   {0,h-r,r,r},{r,h-r,w-2*r,r},{w-r,h-r,r,r}}
  for i,t in ipairs(tex) do
   local a=coords[i];t:ClearAllPoints();t:SetPoint('TOPLEFT',parent,'TOPLEFT',a[1],-a[2]);t:SetSize(a[3],a[4])
  end
 end
 size()
 parent:HookScript('OnSizeChanged',size)
 return tex
end
local function pane(parent,x,y,w,h,style)
 local f=CreateFrame('Frame',nil,parent)
 f:SetPoint('TOPLEFT',parent,'TOPLEFT',x,-y);f:SetSize(w,h)
 skin(f,style or 'panel',11)
 return f
end
local function line(p,x,y,w)
 return img(p,M..'divider.tga',x,y,w,5)
end
local function heading(p,t,x,y,w)
 txt(p,t,x,y,w,26,15,GOLD);line(p,x,y+30,w)
end
local function btn(p,name,x,y,w,h,click,style)
 local b=CreateFrame('Button',nil,p)
 b:SetPoint('TOPLEFT',p,'TOPLEFT',x,-y);b:SetSize(w,h)
 b.c=txt(b,name,6,1,w-12,h-2,12,WHITE,'CENTER')
 b.art=skin(b,style or 'button',10)
 b.activeArt=skin(b,'gold',10)
 b:SetScript('OnClick',click or function() end)
 b:SetScript('OnEnter',function(self)
  self.c:SetTextColor(1,.91,.57)
 end)
 b:SetScript('OnLeave',function(self)
  self.c:SetTextColor(unpack(self.isActive and GOLD or WHITE))
 end)
 b.setActive=function(self,value)
  self.isActive=not not value
  for _,tile in ipairs(self.art)do tile:SetShown(not self.isActive)end
  for _,tile in ipairs(self.activeArt)do tile:SetShown(self.isActive)end
  self.c:SetTextColor(unpack(self.isActive and GOLD or WHITE))
 end
 b:setActive(false)
 return b
end
local function closeButton(p,x,y,callback)
 -- Native Blizzard close button, not a substitute glyph or decorative minus.
 local b=CreateFrame('Button',nil,p,'UIPanelCloseButton')
 b:SetPoint('TOPLEFT',p,'TOPLEFT',x,-y);b:SetSize(32,32)
 b:SetScript('OnClick',callback)
 return b
end

local function icon(p,tex,x,y,n)
 return img(p,tex or 'Interface\\Icons\\INV_Misc_QuestionMark',x,y,n,n)
end
local function prog(p,x,y,w,h)
 local frame=pane(p,x,y,w,h,'row');local fill=frame:CreateTexture(nil,'ARTWORK')
 fill:SetTexture(M..'progress.tga');fill:SetPoint('TOPLEFT',frame,'TOPLEFT',3,-3)
 fill:SetSize(1,math.max(2,h-6))
 return function(v)
  fill:SetWidth(math.max(1,((frame:GetWidth() or w)-6)*math.max(0,math.min(1,tonumber(v) or 0))))
 end,frame
end
local function group(root,title,x,y,w,h)
 local p=pane(root,x,y,w,h,'panel');heading(p,title,14,10,w-28);return p
end
local function profIcon(name)
 name=str(name):lower()
 if name:find('herb')then return 'Interface\\Icons\\INV_Misc_Herb_11'
 elseif name:find('alchem')then return 'Interface\\Icons\\Trade_Alchemy'
 elseif name:find('cook')then return 'Interface\\Icons\\INV_Misc_Food_15'
 elseif name:find('aid')then return 'Interface\\Icons\\Spell_Holy_SealOfSacrifice'
 elseif name:find('fish')then return 'Interface\\Icons\\Trade_Fishing'
 elseif name:find('min')then return 'Interface\\Icons\\Trade_Mining'
 elseif name:find('skin')then return 'Interface\\Icons\\INV_Misc_Pelt_Wolf_01'
 elseif name:find('enchant')then return 'Interface\\Icons\\Trade_Engraving'
 elseif name:find('tailor')then return 'Interface\\Icons\\Trade_Tailoring'
 elseif name:find('engineer')then return 'Interface\\Icons\\Trade_Engineering' end
 return 'Interface\\Icons\\INV_Misc_QuestionMark'
end
local function openBags()
 if type(ToggleAllBags)=='function'then ToggleAllBags()
 elseif type(OpenAllBags)=='function'then OpenAllBags()end
end
local function professionWindow()
 if type(ToggleProfessions)=='function'then ToggleProfessions()
 elseif type(ToggleSpellBook)=='function'then ToggleSpellBook('professions')
 else FF:Message('Open your profession window and refresh recipes.')end
end
local function page(root,name)
 local f=CreateFrame('Frame',nil,root);f:SetPoint('TOPLEFT',root,'TOPLEFT',0,0);f:SetSize(1100,565)
 return f
end
local function side(root,title)
 local left=pane(root,0,0,208,565,'rail');heading(left,title,14,12,180)
 return left
end
local function head(root,ico,title,subtitle)
 icon(root,ico,229,5,36)
 txt(root,title,280,0,600,35,21,GOLD)
 txt(root,subtitle,282,36,746,24,12,DIM)
 line(root,223,66,864)
end
local function bodyPage(p,title,ico,subtitle)
 local rail=side(p,title)
 head(p,ico,title,subtitle)
 return rail
end
local function makeToday(root)
 local v={root=root};local rail=bodyPage(root,'Your Adventure','Interface\\Icons\\INV_Misc_Map_01','Your route, progress and immediate next step')
 btn(rail,'Track current quest',12,55,184,41,function()FF:TrackQuest()end)
 btn(rail,'Open quest map',12,105,184,41,function()FF:MapAction()end)
 btn(rail,'Next suggestion',12,155,184,41,function()FF:SkipQuest()end)
 heading(rail,'PLAYSTYLE',14,226,180)
 v.pr={}
 for i,opt in ipairs({{'balanced','Balanced'},{'level','Fast leveling'},{'gold','More gold'}})do
  v.pr[opt[1]]=btn(rail,opt[2],12,264+(i-1)*49,184,40,function()FF:SetPriority(opt[1])end)
 end
 v.railInfo=txt(rail,'',14,461,180,88,11,DIM,'LEFT',true)
 v.zone=txt(root,'',814,10,270,25,12,GOLD,'RIGHT')
 v.xp=prog(root,879,44,205,13)
 local list=group(root,'QUESTS / PRIORITIZED',223,78,535,270)
 v.questRows={};v.active=nil
 for i=1,5 do
  local b=btn(list,'',13,41+(i-1)*47,509,42,function(self)if self.quest and self.quest.id then FF:ChooseQuest(self.quest.id)end end,'row')
  b.c:Hide();b.ico=icon(b,'Interface\\Icons\\INV_Misc_Map_01',6,5,32)
  b.name=txt(b,'',45,2,445,21,13,WHITE)
  b.detail=txt(b,'',45,22,445,15,11,DIM)
  v.questRows[i]=b
 end
 local selected=group(root,'CURRENT OBJECTIVE',769,78,322,270)
 v.kind=txt(selected,'',14,42,292,22,11,DIM)
 v.questTitle=txt(selected,'',14,77,291,61,20,WHITE,'LEFT',true)
 v.progress=txt(selected,'',14,149,291,37,13,GOLD,'LEFT',true)
 line(selected,14,195,292)
 v.where=txt(selected,'',14,205,289,70,11,DIM,'LEFT',true)
 local steps=group(root,'YOUR LEVELING FLOW',223,360,535,151)
 v.steps={}
 for i=1,3 do
  txt(steps,tostring(i),16,37+(i-1)*34,19,26,12,GOLD,'CENTER')
  v.steps[i]=txt(steps,'',48,37+(i-1)*34,467,29,11,WHITE,'LEFT',true)
 end
 local info=group(root,'CHARACTER STATUS',769,360,322,151)
 v.status={}
 for i=1,3 do v.status[i]=txt(info,'',15,46+(i-1)*34,288,25,12,i==3 and GOLD or WHITE)end
 btn(root,'FIND PICKUPS',223,522,174,38,function()FF.char.discoverView=true;FF:ShowTab('leveling')end)
 btn(root,'WHY THIS ROUTE?',409,522,176,38,function() FF:DescribeRoute()end)
 btn(root,'PROFESSIONS',596,522,176,38,function()FF:ShowTab('skills')end)
 btn(root,'GOLD & MATERIALS',785,522,307,38,function()FF:ShowTab('gold')end)
 return v
end
local function makeLeveling(root)
 local v={root=root};local rail=bodyPage(root,'Quest Planner','Interface\\Icons\\INV_Misc_Map_01','Choose a route or explore reported quest pickups')
 v.mine=btn(rail,'My quests',12,55,184,42,function()FF.char.discoverView=false;FF:Refresh()end)
 v.discover=btn(rail,'Discover quests',12,105,184,42,function()FF.char.discoverView=true;FF.char.discoverPage=1;FF:Refresh()end)
 btn(rail,'Browse other zones',12,155,184,42,function()FF.char.discoverView=true;FF.char.discoverBrowseAll=true;FF:Refresh()end)
 btn(rail,'Resume automatic',12,215,184,42,function()FF:UnpinCurrentQuest()end)
 v.total=txt(root,'',833,14,243,21,12,GOLD,'RIGHT')
 local list=group(root,'AVAILABLE QUESTS',223,78,535,432)
 v.rows={}
 for i=1,5 do
  local b=btn(list,'',12,47+(i-1)*72,509,63,function(self)
   if not self.quest then return end
   if FF.char.discoverView then
    FF.char.discoverSelectedQuestID=self.quest.id
    FF:ShowDiscoveryOnMap(self.quest)
    FF:Refresh()
   elseif self.quest.id then FF:ChooseQuest(self.quest.id)end
  end,'row')
  b.c:Hide();b.ico=icon(b,'Interface\\Icons\\INV_Misc_Map_01',10,12,36)
  b.name=txt(b,'',56,5,441,25,14,WHITE)
  b.detail=txt(b,'',56,30,440,25,11,DIM)
  v.rows[i]=b
 end
 v.empty=txt(list,'No matching quests. Try a different zone or accept an available quest.',18,86,495,100,13,DIM,'LEFT',true)
 local inspect=group(root,'YOUR NEXT ACTION',769,78,322,432)
 v.selected=txt(inspect,'',16,51,285,72,19,WHITE,'LEFT',true)
 v.explain=txt(inspect,'',16,141,285,125,12,DIM,'LEFT',true)
 v.location=txt(inspect,'',16,260,285,33,11,GOLD,'LEFT',true)
 v.action=btn(inspect,'SET QUESTGIVER PIN',13,312,296,40,function()
  if v.target and FF.char.discoverView then FF:ShowDiscoveryOnMap(v.target)
  elseif v.target and v.target.id then FF:ChooseQuest(v.target.id)else FF:MapAction()end
 end)
 v.next=btn(inspect,'NEXT SUGGESTION',13,361,296,40,function()
  if FF.char.discoverView then
   FF.char.discoverSelectedQuestID=nil
   FF.char.discoverPage=math.min((FF.char.discoverPage or 1)+1,math.max(1,math.ceil((v.totalCount or 0)/5)))
   FF:Refresh()
  else FF:SkipQuest() end
 end)
 v.pageLabel=txt(root,'',500,528,311,29,12,DIM,'CENTER')
 btn(root,'PREVIOUS',223,523,137,37,function()FF.char.discoverPage=math.max(1,FF.char.discoverPage-1);FF:Refresh()end)
 btn(root,'NEXT PAGE',952,523,139,37,function()FF.char.discoverPage=FF.char.discoverPage+1;FF:Refresh()end)
 return v
end
local function makeGold(root)
 local v={root=root};local rail=bodyPage(root,'Your Wallet','Interface\\Icons\\INV_Misc_Coin_01','Gold, gathering, material inventory and session tracking')
 v.money=txt(rail,'',14,77,181,58,24,GOLD)
 v.target=txt(rail,'',14,142,181,74,12,DIM,'LEFT',true)
 btn(rail,'Automatic goal',12,250,184,40,function()FF.char.goldTarget=0;FF:Refresh()end)
 btn(rail,'Current +5 gold',12,299,184,40,function()FF.char.goldTarget=math.floor((FF.snapshot.money or 0)/10000)+5;FF:Refresh()end)
 btn(rail,'Current +20 gold',12,348,184,40,function()FF.char.goldTarget=math.floor((FF.snapshot.money or 0)/10000)+20;FF:Refresh()end)
 local cash=group(root,'SESSION CASH FLOW',223,78,535,200)
 v.cash={};for i=1,3 do v.cash[i]=txt(cash,'',17,41+(i-1)*48,502,37,17,i==1 and GREEN or (i==2 and RED or GOLD))end
 local gather=group(root,'GATHER ALONG YOUR ROUTE',223,289,535,218)
 v.gather=txt(gather,'',17,47,495,108,13,WHITE,'LEFT',true)
 btn(gather,'OPEN BAGS',15,164,240,38,openBags)
 btn(gather,'PROFESSION WORKBENCH',267,164,253,38,function()FF:ShowTab('skills')end)
 local mats=group(root,'RECIPE MATERIALS',769,78,322,429)
 v.craft=txt(mats,'',15,46,289,71,15,WHITE,'LEFT',true)
 v.materials={};for i=1,5 do v.materials[i]=txt(mats,'',15,138+(i-1)*42,290,36,12,DIM,'LEFT',true)end
 v.tip=txt(mats,'',15,358,292,50,11,GOLD,'LEFT',true)
 btn(root,'VIEW RECIPES',769,522,322,38,function()FF:ShowTab('skills')end)
 return v
end
local function makeSkills(root)
 local v={root=root};local rail=side(root,'PROFESSIONS')
 v.professions={}
 for i=1,6 do
  local b=btn(rail,'',10,49+(i-1)*68,189,63,function(self)
   FF.char.professionCoachIndex=self.index or 1
   if FF.TryCaptureRecipes then FF:TryCaptureRecipes()end;FF:Refresh()
  end,'row')
  b.c:Hide();b.ico=icon(b,'Interface\\Icons\\INV_Misc_QuestionMark',8,9,35)
  b.name=txt(b,'',52,5,127,25,13,WHITE)
  b.level=txt(b,'',52,28,127,20,11,DIM)
  b.meter=prog(b,52,51,121,8)
  v.professions[i]=b
 end
 v.railTip=txt(rail,'Select a profession. Open its crafting window to read real recipes.',13,478,183,70,11,DIM,'LEFT',true)
 head(root,'Interface\\Icons\\Trade_Alchemy','Profession Flow','Plan your crafts, gather materials, and level efficiently.')
 v.profTitle=txt(root,'',848,9,236,28,13,GOLD,'RIGHT')
 v.profBar=prog(root,850,44,235,12)
 v.best=btn(root,'Best recipes to level now',223,78,209,35,function()FF.char.premiumFilter='best';FF.char.premiumRecipePage=1;FF:Refresh()end)
 v.all=btn(root,'All recipes',440,78,132,35,function()FF.char.premiumFilter='all';FF.char.premiumRecipePage=1;FF:Refresh()end)
 v.need=btn(root,'Materials',580,78,144,35,function()FF.char.premiumFilter='missing';FF.char.premiumRecipePage=1;FF:Refresh()end)
 btn(root,'REFRESH RECIPES',906,78,185,35,function()if FF.TryCaptureRecipes then FF:TryCaptureRecipes()end;FF:Refresh()end)
 local recipes=group(root,'KNOWN RECIPES  /  SKILL-UPS',223,122,533,275)
 txt(recipes,'SKILL',305,36,78,20,10,DIM,'RIGHT')
 txt(recipes,'CAN MAKE',421,36,90,20,10,DIM,'RIGHT')
 v.recipes={}
 for i=1,6 do
  local b=btn(recipes,'',10,57+(i-1)*31,511,29,function(self)
   if self.index then FF:RecipeFlowSelect(self.index);FF:Refresh()end
  end,'row');b.c:Hide()
  b.ico=icon(b,'Interface\\Icons\\INV_Misc_QuestionMark',4,2,25)
  b.name=txt(b,'',36,1,253,27,12,WHITE)
  b.diff=txt(b,'',288,1,102,27,11,GREEN,'RIGHT')
  b.count=txt(b,'',400,1,104,27,12,GOLD,'RIGHT')
  v.recipes[i]=b
 end
 v.recPrev=btn(recipes,'<',12,247,43,23,function()
  FF.char.premiumRecipePage=math.max(1,(FF.char.premiumRecipePage or 1)-1);FF:Refresh()
 end)
 v.recPage=txt(recipes,'',62,247,392,23,10,DIM,'CENTER')
 v.recNext=btn(recipes,'>',464,247,56,23,function()
  FF.char.premiumRecipePage=(FF.char.premiumRecipePage or 1)+1;FF:Refresh()
 end)
 local detail=group(root,'RECIPE  /  REAGENTS',768,122,323,275)
 v.itemIcon=icon(detail,'Interface\\Icons\\INV_Misc_QuestionMark',15,47,48)
 v.recipeName=txt(detail,'',73,42,237,31,15,WHITE)
 v.difficulty=txt(detail,'',74,74,236,25,11,DIM)
 line(detail,13,104,292)
 txt(detail,'REAGENTS',13,109,163,21,12,GOLD)
 txt(detail,'HAVE / NEED',212,109,93,21,10,DIM,'RIGHT')
 v.reagents={}
 for i=1,3 do
  local b=pane(detail,13,133+(i-1)*35,295,32,'row')
  b.ico=icon(b,'Interface\\Icons\\INV_Misc_QuestionMark',4,3,26)
  b.name=txt(b,'',37,1,165,30,12,WHITE)
  b.count=txt(b,'',208,1,77,30,11,GREEN,'RIGHT')
  v.reagents[i]=b
 end
 v.missing=txt(detail,'',15,241,292,29,11,RED,'LEFT',true)
 local flow=group(root,'YOUR PROFESSION FLOW',223,405,533,114)
 v.steps={};v.stepIcons={}
 for i=1,3 do
  txt(flow,tostring(i),12,44+(i-1)*23,19,21,12,GOLD,'CENTER')
  v.stepIcons[i]=icon(flow,'Interface\\Icons\\INV_Misc_QuestionMark',36,44+(i-1)*23,19)
  v.steps[i]=txt(flow,'',65,44+(i-1)*23,448,21,11,WHITE)
 end
 local results=group(root,'RESULTS  /  CRAFTING STATUS',768,405,323,114)
 v.result={}
 for i=1,3 do v.result[i]=txt(results,'',15,45+(i-1)*22,294,20,11,i==3 and GOLD or WHITE)end
 btn(root,'OPEN PROFESSION',223,526,198,36,professionWindow)
 btn(root,'TRACK MATERIALS',432,526,198,36,function()
  local list=FF.RecipeFlowShoppingList and FF:RecipeFlowShoppingList() or {}
  if #list==0 then FF:Message('No missing materials in the selected recipe scan.')
  else local a={};for i=1,math.min(#list,5)do a[#a+1]=str(list[i].need)..'x '..str(list[i].name)end
   FF:Message('Materials: '..table.concat(a,', '))end
 end)
 btn(root,'OPEN BAGS',642,526,192,36,openBags)
 btn(root,'NEXT RECIPE',846,526,245,36,function()
  local d=FF.recipeFlow
  if d and d.recipes and #d.recipes>0 then FF:RecipeFlowSelect(((FF.char.recipeFlowSelected or 1)%#d.recipes)+1);FF:Refresh()end
 end)
 return v
end
local function makeCharacter(root)
 local v={root=root};local rail=bodyPage(root,'Your Character','Interface\\Icons\\INV_Misc_Book_09','Training, talents, equipment and progression')
 -- Native player portrait. On some Forever clients SetPortraitTexture exists
 -- before its image is ready; never hide the PlayerModel just because the API exists.
 local portraitHolder=pane(rail,32,59,144,145,'row')
 local model=CreateFrame('PlayerModel',nil,portraitHolder)
 model:SetPoint('TOPLEFT',portraitHolder,'TOPLEFT',5,-5)
 model:SetSize(134,135)
 model:SetFrameLevel(portraitHolder:GetFrameLevel()+1)
 v.portrait=model
 local live=portraitHolder:CreateTexture(nil,'OVERLAY')
 live:SetPoint('TOPLEFT',portraitHolder,'TOPLEFT',7,-7)
 live:SetSize(130,131)
 v.portraitTexture=live
 -- A class icon is only a fallback, and is hidden once a real player portrait loads.
 local fallback=portraitHolder:CreateTexture(nil,'ARTWORK')
 fallback:SetPoint('TOPLEFT',portraitHolder,'TOPLEFT',30,-31)
 fallback:SetSize(84,84)
 fallback:SetTexture('Interface\\Icons\\INV_Misc_QuestionMark')
 v.portraitFallback=fallback
 v.portraitHolder=portraitHolder
 v.updatePortrait=function()
  if type(UnitExists)=='function' and not UnitExists('player') then return end
  local portraitOK=false
  if type(SetPortraitTexture)=='function' then
   local ok=pcall(SetPortraitTexture,live,'player')
   -- On some clients it returns successfully but leaves an empty texture.
   local texture=live.GetTexture and live:GetTexture()
   portraitOK=ok and texture~=nil and texture~=false and texture~=''
  end
  live:SetShown(portraitOK)
  if portraitOK then
   model:Hide();fallback:Hide()
  else
   -- The native 3D model is the second choice, never hidden merely because
   -- SetPortraitTexture exists. When no model API is present, show class art.
   local modelOK=false
   if model.SetUnit then modelOK=pcall(model.SetUnit,model,'player') end
   model:SetShown(modelOK)
   if modelOK and model.RefreshUnit then pcall(model.RefreshUnit,model) end
   fallback:SetShown(not modelOK)
  end
 end
 local portraitEvents=CreateFrame('Frame',nil,rail)
 portraitEvents:RegisterEvent('PLAYER_ENTERING_WORLD')
 portraitEvents:RegisterEvent('UNIT_PORTRAIT_UPDATE')
 portraitEvents:RegisterEvent('UNIT_MODEL_CHANGED')
 portraitEvents:RegisterEvent('PLAYER_ALIVE')
 portraitEvents:SetScript('OnEvent',function(_,event,unit)
  if not unit or unit=='player' then v.updatePortrait() end
 end)
 v.updatePortrait()
 v.name=txt(rail,'',14,200,180,58,17,WHITE,'CENTER',true)
 v.zone=txt(rail,'',14,266,180,64,12,DIM,'CENTER',true)
 v.money=txt(rail,'',14,353,180,30,15,GOLD,'CENTER')
 local tasks=group(root,'LEVEL-UP CHECKLIST',223,78,535,430)
 v.checks={}
 for i,title in ipairs({'REVIEW TALENTS','VISIT CLASS TRAINER','REPAIR AND REVIEW EQUIPMENT'})do
  local index=i
  local b=btn(tasks,'',13,51+(i-1)*90,509,77,function()
   FF.char.trainingChecks[index]=not FF.char.trainingChecks[index];FF:Refresh()
  end,'row');b.c:Hide()
  b.status=txt(b,'',11,17,42,36,20,GOLD,'CENTER')
  txt(b,title,57,12,430,26,14,WHITE)
  txt(b,'Click to mark completed for this character',57,41,431,21,11,DIM)
  v.checks[i]=b
 end
 v.session=txt(tasks,'',16,358,490,52,12,DIM,'LEFT',true)
 local tips=group(root,'CONTEXT FROM YOUR SESSION',769,78,322,430)
 v.tips={};for i=1,3 do v.tips[i]=txt(tips,'',15,44+(i-1)*123,288,102,12,WHITE,'LEFT',true)end
 btn(root,'OPEN QUEST PLANNER',223,524,262,36,function()FF:ShowTab('leveling')end)
 btn(root,'SETTINGS',827,524,264,36,function()FF:ShowTab('settings')end)
 return v
end
local function makeSettings(root)
 local v={root=root};local rail=bodyPage(root,'Your Experience','Interface\\Icons\\INV_Gizmo_02','Control your guide, routes, and interface preferences')
 txt(rail,'Your interface.\nYour pace.\nYour adventure.',15,73,176,99,19,WHITE,'LEFT',true)
 icon(rail,FF.media..'OfficialCircle.tga',32,181,145)
 txt(rail,'ForeverFlow guides your next step. You control every in-game action.',15,353,176,110,12,DIM,'LEFT',true)
 local opts=group(root,'DISPLAY & QUEST CONTROLS',223,78,535,430)
 local settings={
  {'LIVE GUIDE',function()FF:ToggleGuide()end},
  {'MINIMAP BUTTON',function()FF.char.hideMinimap=not FF.char.hideMinimap;FF:Refresh()end},
  {'AUTO-FOLLOW',function()FF:SetAutoFollow(not FF.char.autoFollow)end},
  {'COMPACT GUIDE',function()FF.char.hudMinimal=not FF.char.hudMinimal;FF:SetGuideCollapsed(FF.char.guideCollapsed);FF:Refresh()end},
  {'UNLOCK GUIDE POSITION',function()FF.char.guideLocked=not FF.char.guideLocked;FF:Refresh()end},
  {'LEVEL-UP CHAT TIPS',function()FF.db.quiet=not FF.db.quiet;FF:Refresh()end},
  {'ADVANCED DETAILS',function()FF.db.mode=FF.db.mode=='advanced' and 'simple' or 'advanced';FF:Refresh()end},
 }
 v.options={}
 for i,entry in ipairs(settings)do
  local b=btn(opts,'',11,43+(i-1)*52,510,45,entry[2],'row');b.c:Hide()
  txt(b,entry[1],15,6,345,31,12,WHITE)
  b.state=txt(b,'',409,6,85,31,12,GREEN,'RIGHT')
  v.options[i]=b
 end
 local tools=group(root,'DISPLAY TOOLS',769,78,322,430)
 v.scale=txt(tools,'',15,49,288,34,14,WHITE)
 btn(tools,'CYCLE GUIDE SCALE',13,98,296,41,function()
  local a=FF.char.guideScale or 1;FF:SetGuideScale(a<.95 and 1 or (a<1.1 and 1.2 or .85))
 end)
 btn(tools,'RESET WINDOW POSITIONS',13,151,296,41,function()
  FF.char.posX=0;FF.char.posY=0;FF.char.guideX=-620;FF.char.guideY=170
  FF.window:ClearAllPoints();FF.window:SetPoint('CENTER',UIParent,'CENTER',0,0)
  FF.guide:ClearAllPoints();FF.guide:SetPoint('CENTER',UIParent,'CENTER',-620,170)
 end)
 line(tools,14,224,293)
 txt(tools,'KEY COMMANDS',15,237,280,26,12,GOLD)
 txt(tools,'/flow  - open dashboard\n/flow discover - quest pickups\n/flow route - route explanation\n/flow stats - session summary',15,271,288,118,12,WHITE,'LEFT',true)
 btn(root,'RETURN TO TODAY',223,524,262,36,function()FF:ShowTab('today')end)
 return v
end
function FF:CreateGuide()
 -- Freeform resizing changes the guide dimensions (not its scale).
 -- Content and buttons reflow to the available width and height.
 local g=CreateFrame('Frame',nil,UIParent)
 -- 19px minimum clearance beneath 29px action buttons (45 + 135 + 29 = 209).
 local initialWidth=math.max(338,math.min(540,tonumber(self.char.guideWidth) or 360))
 local initialHeight=math.max(202,math.min(360,tonumber(self.char.guideHeight) or 220))
 g:SetSize(initialWidth,initialHeight)
 -- Native Blizzard sizing respects the frame's anchors and drag direction.
 if g.SetResizable then g:SetResizable(true) end
 if g.SetResizeBounds then g:SetResizeBounds(338,202,540,360)
 elseif g.SetMinResize then g:SetMinResize(338,202); if g.SetMaxResize then g:SetMaxResize(540,360) end end
 -- Keep existing user scale; resizing no longer manipulates it.
 if not self.char.guideResizeMigration then
  self.char.guideScale=.88
  self.char.guideResizeMigration=true
 end
 g:SetScale(self.char.guideScale or .88)
 g:SetPoint('CENTER',UIParent,'CENTER',self.char.guideX,self.char.guideY)
 g:SetFrameStrata('MEDIUM');g:SetClampedToScreen(true)
 g:SetMovable(true);g:EnableMouse(true);g:RegisterForDrag('LeftButton')
 skin(g,'guide',12)
 g:SetScript('OnDragStart',function(self)
  if not FF.char.guideLocked and not self.ffResizing then self:StartMoving() end
 end)
 g:SetScript('OnDragStop',function(self)
  self:StopMovingOrSizing();FF:SavePosition(self,'guide')
 end)
 icon(g,FF.media..'MinimapIconRound.tga',10,6,31)
 g.heading=txt(g,'ForeverFlow Guide',49,6,180,29,16,GOLD)
 g.status=txt(g,'',251,11,48,18,10,GREEN,'RIGHT')
 g.collapse=btn(g,'-',304,8,21,25,function()FF:SetGuideCollapsed(not FF.char.guideCollapsed)end)
 g.close=closeButton(g,329,2,function()FF:ToggleGuide()end)
 g.headerRule=line(g,12,39,336)
 g.content=CreateFrame('Frame',nil,g)
 g.content:SetPoint('TOPLEFT',g,'TOPLEFT',0,-45);g.content:SetSize(360,165)
 g.kind=txt(g.content,'',13,0,330,17,10,GOLD)
 g.title=txt(g.content,'',13,19,330,31,16,WHITE,'LEFT',true)
 g.where=txt(g.content,'',13,51,331,26,11,DIM,'LEFT',true)
 g.detail=txt(g.content,'',13,79,332,33,12,WHITE,'LEFT',true)
 g.progress,g.progressFrame=prog(g.content,13,116,333,11)
 g.map=btn(g.content,'SET PIN',13,135,105,29,function()FF:MapAction()end)
 g.next=btn(g.content,'NEXT',127,135,105,29,function()FF:SkipQuest()end)
 g.open=btn(g.content,'DETAILS',241,135,105,29,function()
  FF.window:Show();FF.char.visible=true;FF:ShowTab('today')end)
 -- Bottom-right resize grip; drag grows real width/height, independently.
 -- Text and action buttons reflow rather than being uniformly zoomed.
 local grip=CreateFrame('Button',nil,g)
 grip:SetSize(15,15)
 grip:SetPoint('BOTTOMRIGHT',g,'BOTTOMRIGHT',-2,2)
 grip:SetFrameLevel(g:GetFrameLevel()+8)
 grip:EnableMouse(true)
 grip:RegisterForDrag('LeftButton')
 local texture=grip:CreateTexture(nil,'OVERLAY')
 texture:SetAllPoints(grip)
 texture:SetTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up')
 grip:SetHighlightTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight')
 grip:SetPushedTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down')
 local function layoutGuide()
  local width,height=g:GetWidth(),g:GetHeight()
  if not width or not height then return end
  local inner=width-26
  g.headerRule:SetWidth(width-24)
  -- The close, collapse, and status ALWAYS follow the right edge.
  -- The heading is confined to the available space on the left.
  g.close:ClearAllPoints()
  g.close:SetPoint('TOPRIGHT',g,'TOPRIGHT',-3,-2)
  g.collapse:ClearAllPoints()
  g.collapse:SetPoint('TOPRIGHT',g,'TOPRIGHT',-39,-8)
  g.status:ClearAllPoints()
  g.status:SetPoint('TOPRIGHT',g,'TOPRIGHT',-70,-11)
  g.status:SetSize(43,18)
  g.heading:SetWidth(math.max(125,width-185))
  g.content:SetWidth(width)
  g.kind:SetWidth(inner)
  g.title:SetWidth(inner)
  g.where:SetWidth(inner)
  g.detail:SetWidth(inner)
  -- Buttons maintain a 13px outer gutter and a 19px bottom gutter.
  local gap=9
  local actionWidth=(width-26-2*gap)/3
  for i,b in ipairs({g.map,g.next,g.open}) do
   b:ClearAllPoints()
   b:SetPoint('BOTTOMLEFT',g,'BOTTOMLEFT',13+(i-1)*(actionWidth+gap),19)
   b:SetSize(actionWidth,29)
   if b.c then b.c:SetWidth(actionWidth-12) end
  end
  -- Never stretch the progress texture: its fill follows the actual bar width.
  g.progressFrame:ClearAllPoints()
  g.progressFrame:SetPoint('BOTTOMLEFT',g,'BOTTOMLEFT',13,58)
  g.progressFrame:SetWidth(inner)
  -- The objective description gets the free vertical space, but does not
  -- overlap the progress meter or bottom buttons.
  g.detail:SetHeight(math.max(20,math.min(58,height-174)))
  g.progress(g.guideProgress or 0)
 end
 g.layoutGuide=layoutGuide
 g:HookScript('OnSizeChanged',layoutGuide)
 layoutGuide()
 local function stopResize(self)
  if not g.ffResizing then return end
  g:StopMovingOrSizing()
  g.ffResizing=nil
  FF.char.guideWidth=math.floor(g:GetWidth()+.5)
  FF.char.guideHeight=math.floor(g:GetHeight()+.5)
  -- Save the FINAL location rather than re-centering while dragging.
  FF:SavePosition(g,'guide')
  if FF.Refresh then FF:Refresh() end
 end
 grip:SetScript('OnDragStart',function(self)
  if FF.char.guideLocked or FF.char.guideCollapsed then return end
  if not g.StartSizing then return end
  -- Lock the top-left corner in place so this behaves like a desktop window.
  local left,top=g:GetLeft(),g:GetTop()
  if not left or not top then return end
  local frameScale=(g.GetEffectiveScale and g:GetEffectiveScale()) or 1
  local parentScale=(UIParent.GetEffectiveScale and UIParent:GetEffectiveScale()) or 1
  local factor=frameScale/math.max(.01,parentScale)
  g:ClearAllPoints()
  g:SetPoint('TOPLEFT',UIParent,'BOTTOMLEFT',left*factor,top*factor)
  g.ffResizing=true
  g:StartSizing('BOTTOMRIGHT')
 end)
 grip:SetScript('OnDragStop',stopResize)
 grip:SetScript('OnMouseUp',function(self)if g.ffResizing then stopResize(self)end end)
 grip:SetScript('OnEnter',function(self)
  if not GameTooltip then return end
  GameTooltip:SetOwner(self,'ANCHOR_TOP')
  GameTooltip:AddLine('Resize ForeverFlow Guide',1,.8,.4)
  GameTooltip:AddLine('Drag to change width and height independently.',1,1,1)
  GameTooltip:Show()
 end)
 grip:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide()end end)
 g.resizeGrip=grip
 self.guide=g;self:SetGuideCollapsed(self.char.guideCollapsed)
 g:SetShown(self.char.guideVisible)
end
function FF:SetGuideCollapsed(value)
 if not self.guide then return end
 self.char.guideCollapsed=not not value
 local g=self.guide
 local compact=self.char.hudMinimal==true
 g:SetHeight(value and 44 or (compact and math.max(202,tonumber(self.char.guideHeight) or 220) or (tonumber(self.char.guideHeight) or 220)))
 g.content:SetShown(not value)
 if g.collapse and g.collapse.c then g.collapse.c:SetText(value and '+' or '-') end
 for _,b in ipairs({g.map,g.next,g.open}) do if b then b:SetShown(not compact and not value) end end
 if g.where then g.where:SetShown(not value) end
 if g.detail then g.detail:SetShown(not value) end
 if g.progressFrame then g.progressFrame:SetShown(not value) end
 if g.resizeGrip then g.resizeGrip:SetShown(not value and not compact) end
end
function FF:PositionMinimapIcon()
 if not self.minimap or not Minimap then return end
 local a=math.rad(self.char.minimapAngle or 42)
 local radius=(Minimap.GetWidth and Minimap:GetWidth() or 140)/2+11
 self.minimap:ClearAllPoints()
 self.minimap:SetPoint('CENTER',Minimap,'CENTER',math.cos(a)*radius,math.sin(a)*radius)
end
function FF:CreateMinimapButton()
 if not Minimap then return end
 local b=CreateFrame('Button',nil,UIParent)
 b:SetSize(35,35);b:SetFrameStrata('HIGH')
 icon(b,FF.media..'MinimapIconRound.tga',1,1,33)
 b:RegisterForClicks('LeftButtonUp','RightButtonUp')
 b:SetScript('OnClick',function(_,button)if button=='RightButton'then FF:ToggleGuide()else FF:Toggle()end end)
 b:RegisterForDrag('LeftButton')
 b:SetScript('OnDragStart',function(self)
  self:SetScript('OnUpdate',function()
   if not GetCursorPosition then return end
   local x,y=GetCursorPosition();local scale=UIParent:GetEffectiveScale() or 1
   local cx,cy=Minimap:GetCenter()
   if x and y and cx and cy then
    local dx,dy=x/scale-cx,y/scale-cy
    local a=(math.atan2 and math.atan2(dy,dx)) or (atan2 and atan2(dy,dx)) or math.atan(dy/(dx==0 and .00001 or dx))
    FF.char.minimapAngle=math.deg(a);FF:PositionMinimapIcon()
   end
  end)
 end)
 b:SetScript('OnDragStop',function(self)self:SetScript('OnUpdate',nil)end)
 self.minimap=b;self:PositionMinimapIcon();b:SetShown(not self.char.hideMinimap)
end
function FF:CreateUI()
 if self.window then return end
 local win=CreateFrame('Frame',nil,UIParent)
 win:SetSize(W,H);win:SetPoint('CENTER',UIParent,'CENTER',self.char.posX,self.char.posY)
 win:SetFrameStrata('DIALOG');win:SetClampedToScreen(true)
 win:SetMovable(true);win:EnableMouse(true);win:RegisterForDrag('LeftButton')
 skin(win,'window',14)
 win:SetScript('OnDragStart',function(self)if not FF.char.locked then self:StartMoving()end end)
 win:SetScript('OnDragStop',function(self)self:StopMovingOrSizing();FF:SavePosition(self,'main')end)
 self.window=win
 local header=pane(win,10,10,1140,75,'header')
 icon(header,FF.media..'MinimapIconRound.tga',12,7,53)
 img(header,FF.media..'HeaderWordmark.tga',76,10,244,53)
 txt(header,'Smart Leveling + Gold',80,57,238,15,11,WHITE)
 self.tabButtons={};self.pages={};self.views={}
 local nav={{'today','Today'},{'leveling','Leveling'},{'gold','Gold'},{'skills','Skills'},
  {'character','Character'},{'settings','Settings'}}
 for i,v in ipairs(nav)do
  self.tabButtons[v[1]]=btn(header,v[2],337+(i-1)*126,22,118,40,function()FF:ShowTab(v[1])end,'tab')
 end
 closeButton(header,1104,6,function()FF:Toggle()end)
 local container=CreateFrame('Frame',nil,win)
 container:SetPoint('TOPLEFT',win,'TOPLEFT',20,-92);container:SetSize(1100,565)
 self.pages.today=page(container,'today');self.views.today=makeToday(self.pages.today)
 self.pages.leveling=page(container,'leveling');self.views.leveling=makeLeveling(self.pages.leveling)
 self.pages.gold=page(container,'gold');self.views.gold=makeGold(self.pages.gold)
 self.pages.skills=page(container,'skills');self.views.skills=makeSkills(self.pages.skills)
 self.pages.character=page(container,'character');self.views.character=makeCharacter(self.pages.character)
 self.pages.settings=page(container,'settings');self.views.settings=makeSettings(self.pages.settings)
 local footer=pane(win,10,660,1140,39,'footer')
 txt(footer,'FOREVERFLOW   •   YOU PLAY, WE GUIDE',14,8,530,21,10,DIM)
 txt(footer,'WoW FOREVER  /  '..str(self.version),793,8,309,21,10,DIM,'RIGHT')
 self:CreateGuide();self:CreateMinimapButton()
 self:ShowTab(self.char.activeTab or 'today')
 win:SetShown(self.char.visible==true)
 self:Refresh()
end
function FF:ShowTab(name)
 if not self.pages or not self.pages[name] then return end
 self.char.activeTab=name
 for k,v in pairs(self.pages)do v:SetShown(k==name)end
 for k,v in pairs(self.tabButtons)do v:setActive(k==name)end
 if name=='skills' and self.TryCaptureRecipes then self:TryCaptureRecipes()end
 self:Refresh()
end
function FF:UpdateUI()
 if not self.views or not self.snapshot or not self.plan then return end
 local s=self.snapshot;local plan=self.plan;local route=self.routeAdvice or {}
 local money=self.MoneyText and self:MoneyText(s.money or 0) or '--'
 local t=self.views.today
 t.zone:SetText(cut(str(s.zone)..'  /  Lv '..str(s.level),35))
 t.xp(s.xpPercent and s.xpPercent/100 or 0)
 for k,b in pairs(t.pr)do b:setActive(self.char.priority==k)end
 t.railInfo:SetText('AUTO FOLLOW  '..(self.char.autoFollow and 'ON' or 'OFF')..'\n'..cut(str(route.kind or 'Live quest information'),66))
 for i,b in ipairs(t.questRows)do
  local q=s.quests and s.quests[i];b.quest=q;b:SetShown(q~=nil)
  if q then b.name:SetText(cut(q.title,52));b.detail:SetText(cut(q.firstObjective or (q.done and 'Ready to turn in' or 'Accepted quest'),66))
   b.ico:SetTexture(q.done and 'Interface\\Icons\\INV_Misc_Note_02' or 'Interface\\Icons\\INV_Misc_Map_01')
   b:setActive(plan.quest and q.id==plan.quest.id)
  end
 end
 t.kind:SetText(str(plan.category or 'NEXT QUEST'))
 t.questTitle:SetText(cut(plan.title,70))
 t.progress:SetText(cut(plan.detail,79))
 t.where:SetText(cut(str(plan.where or s.zone),100))
 t.steps[1]:SetText('Focus: '..cut(plan.title,56))
 t.steps[2]:SetText(cut(route.reason or plan.detail,108))
 t.steps[3]:SetText(cut(route.next or 'Continue nearby quest objectives',108))
 t.status[1]:SetText('Level '..str(s.level)..' '..str(s.className)..'   •   Durability '..str(s.durability or '--')..'%')
 t.status[2]:SetText('Quests '..str(s.questCount or 0)..'   •   Ready '..str(s.questComplete or 0)..'   •   Bags '..str(s.bagFree or '?')..' free')
 t.status[3]:SetText(money)
 local l=self.views.leveling
 local discovery=self.char.discoverView
 l.mine:setActive(not discovery);l.discover:setActive(discovery)
 local list={};if discovery then
  if self.FindDiscoveries then local ok,v=pcall(self.FindDiscoveries,self,s);if ok and type(v)=='table'then list=v end end
 else list=s.quests or {} end
 local total=#list; l.totalCount=total
 local pages=math.max(1,math.ceil(total/5))
 local pg=math.max(1,math.min(pages,tonumber(self.char.discoverPage) or 1));self.char.discoverPage=pg
 l.total:SetText(total..(discovery and ' REPORTED PICKUPS' or ' ACTIVE QUESTS'))
 l.pageLabel:SetText('PAGE '..pg..' / '..pages)
 l.target=nil
 if discovery and self.char.discoverSelectedQuestID then
  for _,q in ipairs(list)do if q.id==self.char.discoverSelectedQuestID then l.target=q;break end end
 end
 for i,b in ipairs(l.rows)do
  local q=list[(pg-1)*5+i];b.quest=q;b:SetShown(q~=nil)
  if q then
   b.name:SetText(cut(q.title or q.name,55))
   b.detail:SetText(cut(discovery and (q.npc or 'Pickup not yet verified') or (q.firstObjective or 'Accepted quest'),90))
   if not l.target then l.target=q end
   b:setActive(l.target and q.id==l.target.id)
  end
 end
 l.empty:SetShown(total==0)
 l.selected:SetText(l.target and cut(l.target.title,70) or 'No quest selected')
 l.location:SetText(discovery and (l.target and l.target.x and l.target.y
   and ('Reported position: '..str(l.target.mapName or '?')..' '..string.format('%.1f, %.1f',l.target.x,l.target.y))
   or 'Quest-giver location not verified') or 'Accepted quest: click to focus')
 l.action.c:SetText(discovery and 'SET QUESTGIVER PIN' or 'FOCUS / OPEN MAP')
 l.explain:SetText(l.target and (discovery and ('Reported pickup: '..str(l.target.npc or 'Unverified')..'\nZone: '..str(l.target.mapName or '?')) or str(l.target.firstObjective or 'Click a quest to focus it.')) or 'Discover quest pickups or accept quests to begin routing.')
 local g=self.views.gold
 g.money:SetText(money)
 g.target:SetText(self.char.goldTarget>0 and ('Goal: '..self:MoneyText(self.char.goldTarget*10000)) or 'Automatic gold goal')
 local ss=s.session or {}
 g.cash[1]:SetText('EARNED      +'..self:MoneyText(ss.earned or 0))
 g.cash[2]:SetText('SPENT       -'..self:MoneyText(ss.spent or 0))
 g.cash[3]:SetText('NET             '..self:MoneyText((ss.earned or 0)-(ss.spent or 0),true))
 g.gather:SetText(cut(str(s.goldTip or 'Gather along your quest route.'),250)..'\n\nFree bag spaces: '..str(s.bagFree or '?'))
 local recipe=self.RecipeFlowSelected and self:RecipeFlowSelected() or nil
 local missing=self.RecipeFlowShoppingList and self:RecipeFlowShoppingList() or {}
 g.craft:SetText(recipe and ('Selected: '..str(recipe.name)) or 'Open a profession to scan real recipes.')
 for i,f in ipairs(g.materials)do local m=missing[i];f:SetText(m and (str(m.need)..' x '..str(m.name)) or '')end
 g.tip:SetText(recipe and (#missing==0 and 'All materials available for one craft.' or 'Counts reflect the last profession scan.') or 'No fictional item prices or drop rates.')
 local sk=self.views.skills
 local profs={}
 for _,p in ipairs(s.professions and s.professions.primary or {})do profs[#profs+1]=p end
 for _,p in ipairs(s.professions and s.professions.secondary or {})do profs[#profs+1]=p end
 local ix=math.max(1,math.min(#profs,tonumber(self.char.professionCoachIndex) or 1))
 for i,b in ipairs(sk.professions)do
  local p=profs[i];b.index=i;b:SetShown(p~=nil)
  if p then
   b.ico:SetTexture(profIcon(p.name));b.name:SetText(cut(p.name,20))
   b.level:SetText(str(p.skill)..' / '..str(p.cap or '?'))
   b.meter((p.cap or 0)>0 and p.skill/p.cap or 0)
   b:setActive(i==ix)
  end
 end
 local active=profs[ix]
 sk.profTitle:SetText(active and (str(active.name)..'  '..str(active.skill)..' / '..str(active.cap)) or 'No trained professions')
 sk.profBar(active and (active.cap or 0)>0 and active.skill/active.cap or 0)
 local d=self.recipeFlow
 local recipes=d and d.recipes or {}
 local choice=recipe
 local filter=self.char.premiumFilter or 'best'
 local indexes={}
for i,r in ipairs(recipes)do
  if filter=='missing' then
   if (r.missingTotal or 0)>0 then indexes[#indexes+1]=i end
  elseif filter=='best' then
   if r.difficulty~='trivial' and r.difficulty~='gray' then indexes[#indexes+1]=i end
  else indexes[#indexes+1]=i end
 end
 local pagesR=math.max(1,math.ceil(#indexes/6))
 local pageR=math.min(pagesR,math.max(1,tonumber(self.char.premiumRecipePage) or 1));self.char.premiumRecipePage=pageR
 sk.best:setActive(filter=='best');sk.all:setActive(filter=='all');sk.need:setActive(filter=='missing')
 sk.recPrev:SetShown(pageR>1);sk.recNext:SetShown(pageR<pagesR)
 sk.recPage:SetText(#recipes>0 and ('RECIPE PAGE '..pageR..' / '..pagesR..'   •   '..#recipes..' observed recipes') or 'Open a profession window to load your recipes')
 for i,b in ipairs(sk.recipes)do
  local idx=indexes[(pageR-1)*6+i];local r=idx and recipes[idx];b.index=idx;b:SetShown(r~=nil)
  if r then
   b.ico:SetTexture(r.texture or 'Interface\\Icons\\INV_Misc_QuestionMark')
   b.name:SetText(cut(r.name,32));b.diff:SetText(str(r.difficulty or '?'))
   b.count:SetText(str(r.available or 0));b:setActive(idx==self.char.recipeFlowSelected)
  end
 end
 sk.itemIcon:SetTexture(choice and choice.texture or 'Interface\\Icons\\INV_Misc_QuestionMark')
 sk.recipeName:SetText(choice and cut(choice.name,33) or 'No recipe selected')
 sk.difficulty:SetText(choice and ('Difficulty: '..str(choice.difficulty or 'Unknown')) or 'Select a learned recipe')
 for i,b in ipairs(sk.reagents)do
  local r=choice and choice.reagents and choice.reagents[i];b:SetShown(r~=nil)
  if r then
   b.ico:SetTexture(r.texture or 'Interface\\Icons\\INV_Misc_QuestionMark')
   b.name:SetText(cut(r.name,23));b.count:SetText(str(r.owned)..' / '..str(r.need))
   b.count:SetTextColor(unpack((r.missing or 0)>0 and RED or GREEN))
  end
 end
 sk.missing:SetText(#missing>0 and ('Missing materials: '..#missing..' kinds') or (choice and 'Materials ready or not yet scanned' or ''))
 sk.steps[1]:SetText(choice and 'Choose '..cut(choice.name,44) or 'Open your profession spellbook')
 sk.stepIcons[1]:SetTexture(profIcon(active and active.name or 'Alchemy'))
 sk.steps[2]:SetText(#missing>0 and ('Gather / buy '..str(missing[1].need)..' '..cut(missing[1].name,39)) or 'Inspect ingredients in your bags')
 sk.stepIcons[2]:SetTexture(#missing>0 and (missing[1].texture or 'Interface\\Icons\\INV_Misc_Herb_11') or 'Interface\\Icons\\INV_Misc_Bag_08')
 sk.steps[3]:SetText(choice and 'Craft using the game profession window' or 'Select a known recipe to plan a craft')
 sk.stepIcons[3]:SetTexture(choice and (choice.texture or 'Interface\\Icons\\Trade_Alchemy') or 'Interface\\Icons\\Trade_Alchemy')
 sk.result[1]:SetText(choice and ('Craftable: '..str(choice.available or 0)) or 'No recipe data collected')
 sk.result[2]:SetText(choice and ('Difficulty: '..str(choice.difficulty or '?')) or 'Skill-ups depend on game data')
 sk.result[3]:SetText('No invented vendor prices or XP estimates')
 local c=self.views.character
 if c.updatePortrait and c.portraitTexture and not c.portraitTexture:IsShown() then c.updatePortrait() end
 c.name:SetText('Level '..str(s.level)..' '..str(s.className))
 c.zone:SetText(str(s.zone));c.money:SetText(money)
 for i,b in ipairs(c.checks)do b.status:SetText(self.char.trainingChecks[i] and '|cff70df81✓|r' or '[ ]')end
 c.session:SetText('Quest turn-ins: '..str(ss.questTurns or 0)..'   •   XP earned: '..str(ss.xpEarned or 0))
 for i,f in ipairs(c.tips)do f:SetText(cut(s.tips and s.tips[i] or 'Review your talents and gear as you level.',200))end
 local set=self.views.settings
 local toggles={self.guide and self.guide:IsShown(),not self.char.hideMinimap,self.char.autoFollow,self.char.hudMinimal,
  not self.char.guideLocked,not self.db.quiet,self.db.mode=='advanced'}
 for i,b in ipairs(set.options)do b.state:SetText(toggles[i] and 'ON' or 'OFF')
  b.state:SetTextColor(unpack(toggles[i] and GREEN or DIM))end
 set.scale:SetText('Guide scale: '..math.floor((self.char.guideScale or 1)*100)..'%')
 if self.minimap then self.minimap:SetShown(not self.char.hideMinimap)end
 if self.guide then
  self.guide.kind:SetText(cut(plan.category or 'QUESTING NEXT',37))
  self.guide.title:SetText(cut(plan.title,65))
  self.guide.where:SetText(cut(str(plan.where or s.zone),76))
  self.guide.detail:SetText(cut(plan.detail,100))
  local q=plan.quest
  local count,required=0,0
  if q then for _,o in ipairs(q.objectives or {})do
   local n=tonumber(o.required) or 0
   if n>0 then required=required+n;count=count+math.min(n,tonumber(o.current) or 0)end
  end end
  self.guide.guideProgress=required>0 and count/required or 0
  self.guide.progress(self.guide.guideProgress)
  self.guide.status:SetText(self.char.autoFollow and 'AUTO' or 'MANUAL')
 end
end
